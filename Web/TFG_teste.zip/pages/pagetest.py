import streamlit as st
from datetime import time, date

appointment = st.slider(
    "Schedule your appointment:",
    value=(time(11, 30), time(12, 45)))
st.write(appointment[0])

st.write(appointment[0].hour)
st.write(appointment[0].minute)
st.write(str(appointment[0].hour) + ":" + str(appointment[0].minute))

st.write()

print(type(str(date.today())))