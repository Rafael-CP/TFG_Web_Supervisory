#4-👤User Configuration.py
import streamlit as st

if st.button(':leftwards_arrow_with_hook:',key="1"):
    st.switch_page("login.py")
