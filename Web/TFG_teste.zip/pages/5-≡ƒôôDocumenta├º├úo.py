import streamlit as st

with open("documentation/MAX20-en_V420.pdf", "rb") as pdf_file:
    PDFfile = pdf_file.read()

st.download_button(label="Download PDF",
                    data=PDFfile,
                    file_name="MAX20-en_V420.pdf")
