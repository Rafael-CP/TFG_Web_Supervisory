import streamlit as st
# Bibliotecas necessárias para comunicação com servidor OPC UA
import asyncio
import pandas as pd # Gerenciamento de dataframes
from datetime import date, time
from asyncua import *
from opcua import ua
from sqlalchemy import * # Comunicação com o banco de dados


if st.session_state["authentication_status"] is None:
    st.switch_page("login.py")  

url = "opc.tcp://127.0.0.1:4840/"
conn = st.connection('mysql', type='sql') # C:\Users\Rafael\.streamlit\secrets.toml

async def main():
   async with Client(url=url) as client:
    st.write("WIP")
        
    opcao_db = st.selectbox("Selecione o Banco de Dados a ser analisado", ("Parâmetros", "Comando", "Análise", "Status"))

    # Seletor de quantidade de dados a serem exibidos na tabela.
    num_db = st.slider("Escolha o período dos dados que deseja analisar", value=(time(12, 00), time(13, 00)))
    # adicionar seletor de dias do mes https://docs.streamlit.io/develop/api-reference/widgets/st.date_input
    query_db = 'SELECT * FROM %s WHERE TIME BETWEEN "%s" AND "%s"' % (opcao_db, (str(date.today())) + " " + str(num_db[0].hour) + ":" + str(num_db[0].minute), (str(date.today())) + " " + str(num_db[1].hour) + ":" + str(num_db[1].minute))
    df = conn.query(query_db, ttl=0)
    st.dataframe(df)

if __name__ == "__main__":

    asyncio.run(main())