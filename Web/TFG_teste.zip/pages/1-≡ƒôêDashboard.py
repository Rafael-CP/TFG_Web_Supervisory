import streamlit as st # Desenvolvimento de Aplicação Web
import asyncio
from asyncua import *
from opcua import ua # MANTENHA O ARQUIVO opcua.py NO DIRETORIO DESTE PROGRAMA - MOTIVO DESCONHECIDO :)
from sqlalchemy import * # Comunicação com o banco de dados
import plotly.express as px # Plot de gráficos

st.set_page_config(page_title='Dashboard', page_icon=':robot_face:', layout='wide')

if st.session_state["authentication_status"] is None:
    st.switch_page("🔐Login.py")  

import streamlit_authenticator as stauth
import yaml
from yaml.loader import SafeLoader

with open('config.yaml') as file:
    config = yaml.load(file, Loader=SafeLoader)

authenticator = stauth.Authenticate(
    config['credentials'],
    config['cookie']['name'],
    config['cookie']['key'],
    config['cookie']['expiry_days'],
    config['preauthorized']
)

authenticator.logout("Sair", "sidebar")


st.sidebar.markdown("""
    <style>

        [data-testid="stSidebarNav"]::before {
            content: "Supervisório Web";
            margin-left: 20px;
            margin-top: 20px;
            font-size: 25px;
            position: relative;
            top: 80px;
        }
    </style>           
                    
    <style>
    [data-testid='stSidebarNav'] > ul {
        min-height: 65vh;
    } 
    </style>
                    
    <style>
    button[title="View fullscreen"]{
        visibility: hidden;}
    </style>
""", unsafe_allow_html=True)

conn = st.connection('mysql', type='sql') # C:\Users\Rafael\.streamlit\secrets.toml

# Endereço do servidor para conexão com o cliente OPC UA
url = "opc.tcp://127.0.0.1:4840/"

placeholder = st.empty()

async def main():
    async with Client(url=url) as client:      

        while(True):
            with placeholder.container():

                df = conn.query('SELECT * FROM análise ORDER BY Time DESC LIMIT 500;', ttl=0)

                col1, col2= st.columns(2)
                
                with col1:
                    fig = px.line(df, x=df["Time"], y=df["Position"], labels={"Position" : "Posição", "Time" : "Tempo"}, title="Posição do Eixo")
                    fig.update_layout({"uirevision": "foo"}, overwrite=True,width=600, title_x=0.5)
                    st.write(fig)

                with col2:
                    fig = px.line(df, x=df["Time"], y=df["Velocity"], labels={"Velocity" : "Velocidade", "Time" : "Tempo"}, title="Velocidade do Eixo")
                    fig.update_layout({"uirevision": "foo"}, overwrite=True,width=600, title_x=0.5)
                    st.write(fig)
            
if __name__ == "__main__":
  asyncio.run(main())